#include "syscall.h" 
#include "copyright.h" 
#define maxlen 32 

int main() 
{ 
	int len; 
	char filename[maxlen +1]; 
	/*Create a file*/ 
	if (Create("text.txt") == -1) 
	{ 
		printf("\n Error create file ");
		// xuất thông báo lỗi tạo tập tin 
	} 
	else 
	{ 
		printf("\n Success create file ");
		// xuất thông báo tạo tập tin thành công 
	} 
	Halt(); 
}
